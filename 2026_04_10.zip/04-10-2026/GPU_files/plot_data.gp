
# Set the terminal type and output file
set terminal png size 800,600
set output 'Heateqn_1D.png'

# Set titles and labels
set title "Solution"
set xlabel "x"
set ylabel "U"

# Enable grid
set grid

# Set line styles
set style line 1 lc "blue" lt 1 lw 2 pt 7   # Blue line
set style line 2 lc "red" lt 1 lw 2 pt 5   # Red line


# Setting the plot limits
set xrange [0:1]
set yrange [0:1.2]

# Plot functions
plot \
'Input_1D.dat' using 1:2 title "Input" with lines lw 2, \
'Output_1D.dat' using 1:2 title "Output" with lines lw 2, \
'Analytical_1D.dat' every 10 using 1:2 title "Analytical"
