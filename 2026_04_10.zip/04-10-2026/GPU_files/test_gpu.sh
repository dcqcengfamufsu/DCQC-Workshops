#!/bin/bash

#SBATCH --job-name="gpu_test"
#SBATCH --ntasks=1
#SBATCH --mail-type="ALL"
#SBATCH -t 1:00

# Here is the magic line to ensure we're running on a node with GPUs
#SBATCH --gres=gpu:1


#SBATCH -A gpu_q
#SBATCH --output=gpu_test.out
#SBATCH --error=gpu_test.err

# NVIDIA Library
module load nvhpc

# Print out GPU information
/usr/bin/nvidia-smi -L
