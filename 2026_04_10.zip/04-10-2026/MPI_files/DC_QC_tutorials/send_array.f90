program send_array
  use mpi
  implicit none
  integer :: rank, ierr, i
  integer :: status(MPI_STATUS_SIZE)
  real(8) :: data(5)

  call MPI_Init(ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, rank, ierr)

  if (rank == 0) then
    data = [10.0d0, 20.0d0, 30.0d0, 40.0d0, 50.0d0]
    ! Send all 5 elements — count is 5
    call MPI_Send(data, 5, MPI_DOUBLE_PRECISION, 1, 0, MPI_COMM_WORLD, ierr)
    write(*,*) 'Rank 0: sent the array'

  else if (rank == 1) then
    call MPI_Recv(data, 5, MPI_DOUBLE_PRECISION, 0, 0, MPI_COMM_WORLD, status, ierr)
    write(*,*) 'Rank 1: received:', (data(i), i=1,5)
  end if

  call MPI_Finalize(ierr)
end program