program scatter_gather
  use mpi
  implicit none
  integer :: rank, nprocs, ierr, i, chunk
  integer, parameter :: N = 8        ! total array size
  real(8) :: full_array(N)           ! used by rank 0 only
  real(8), allocatable :: piece(:)  ! each process works on its piece

  call MPI_Init(ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, rank,   ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, nprocs, ierr)

  ! How many elements each process gets (e.g. 8/4 = 2)
  chunk = N / nprocs
  allocate(piece(chunk))

  ! Rank 0 fills the original array with 1, 2, 3, ..., 8
  if (rank == 0) then
    do i = 1, N
      full_array(i) = real(i, 8)
    end do
    write(*,*) 'Starting array:', full_array
  end if

  ! Scatter: rank 0 sends each process its chunk
  call MPI_Scatter( &
    full_array, chunk, MPI_DOUBLE_PRECISION, &  ! send from rank 0
    piece,      chunk, MPI_DOUBLE_PRECISION, &  ! receive into each rank's piece
    0, MPI_COMM_WORLD, ierr)

  ! Each process doubles its own piece (the "parallel work")
  piece = piece * 2.0d0
  write(*,*) 'Rank', rank, ': my piece after doubling:', piece

  ! Gather: collect all pieces back into full_array on rank 0
  call MPI_Gather( &
    piece,      chunk, MPI_DOUBLE_PRECISION, &  ! each rank sends its piece
    full_array, chunk, MPI_DOUBLE_PRECISION, &  ! rank 0 collects all
    0, MPI_COMM_WORLD, ierr)

  if (rank == 0) then
    write(*,*) 'Final array:', full_array
    ! Expected: [2, 4, 6, 8, 10, 12, 14, 16]
  end if

  deallocate(piece)
  call MPI_Finalize(ierr)
end program