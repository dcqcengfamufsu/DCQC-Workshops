!=============================================================================
!  print_profile
!  Rank 0 gathers the owned points from every rank and prints a bar chart.
!=============================================================================
module solver_utils
contains 
subroutine print_profile(T, n_own, noverlap, rank, nprocs, t_now, N_global)
  use mpi
  implicit none
  real(8),  intent(in) :: T(:)
  integer,  intent(in) :: n_own, noverlap, rank, nprocs, N_global
  real(8),  intent(in) :: t_now

  real(8), allocatable :: T_global(:)
  integer  :: ierr, i, bar_len
  character(len=52) :: bar

  ! Send only the OWNED points (not the overlap region) to rank 0
  if (rank == 0) allocate(T_global(N_global))

  call MPI_Gather( &
    T(noverlap + 1), n_own, MPI_DOUBLE_PRECISION, &   ! each rank sends owned pts
    T_global,        n_own, MPI_DOUBLE_PRECISION, &   ! rank 0 collects
    0, MPI_COMM_WORLD, ierr)

  if (rank == 0) then
    write(*,'(A,F6.2,A)') '  t = ', t_now, ' s'
    do i = 1, N_global
      bar_len = int(max(0.0d0, min(100.0d0, T_global(i))) / 100.0d0 * 50)
      bar     = repeat('█', bar_len)
      write(*,'(A,I3,A,F6.1,A,A)') &
        '  x[', i, '] =', T_global(i), ' | ', trim(bar)
    end do
    write(*,*)
    deallocate(T_global)
  end if

end subroutine print_profile
end module


!=============================================================================
!  heat1d.f90  —  1D Heat Conduction with Overlapping Domain Decomposition
!
!  PHYSICS
!  -------
!  We solve the 1D heat equation on a rod of length L = 1.0 m:
!
!      dT/dt  =  alpha * d²T/dx²
!
!  Left end held at T = 100°C, right end at T = 0°C.
!  We watch heat diffuse from left to right over time.
!
!
!  WHAT IS AN OVERLAP REGION?
!  --------------------------
!  Instead of each process owning only its own points, each process
!  deliberately owns a few EXTRA points on each side — these are real
!  copies of its neighbour's boundary points.  The number of extra
!  points on each side is called "noverlap".
!
!  noverlap is determined by the NUMERICAL SCHEME being used:
!
!    3-point stencil  (2nd-order central difference, this program):
!        T_new(i) = T(i) + r*(T(i-1) - 2*T(i) + T(i+1))
!        needs 1 point from each neighbour  →  noverlap = 1
!
!    5-point stencil  (4th-order):
!        needs 2 points from each neighbour  →  noverlap = 2
!
!    7-point stencil  (6th-order):
!        needs 3 points from each neighbour  →  noverlap = 3
!
!  The overlap points are NOT ghost cells.  They are real temperature
!  values that belong to the neighbour's domain.  After each time step
!  the overlap regions become stale and must be refreshed by exchanging
!  exactly noverlap values with each neighbour.
!
!
!  DOMAIN LAYOUT  (4 processes, N_global = 16, noverlap = 1)
!  ----------------------------------------------------------
!
!  Global index:  0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15
!
!  Rank 0 owns:  [0  1  2  3  4]          <-- 4 interior + 1 overlap on right
!  Rank 1 owns:     	  [3  4  5  6  7  8]    <-- 1 overlap left + 4 interior + 1 right
!  Rank 2 owns:           			  [7  8  9 10 11 12]
!  Rank 3 owns:                 				 [11 12 13 14 15]
!
!  Overlap exchange after each step (arrows show direction of data flow):
!
!   Rank 0  ──sends T_local(n_own)──►  Rank 1 overlap_left(1)
!   Rank 1  ──sends T_local(1)     ──► Rank 0 overlap_right(1)
!
!   Rank 1  ──sends T_local(n_own)──►  Rank 2 overlap_left(1)
!   Rank 2  ──sends T_local(1)     ──► Rank 1 overlap_right(1)
!   ... and so on between every neighbouring pair.
!
!  The exchange is purely PEER-TO-PEER.  Rank 0 has NO special role
!  during the time loop.  Every rank talks only to its two neighbours.
!
!
!  ARRAY INDEXING  (noverlap = 1 example)
!  ---------------------------------------
!  Each rank allocates T(1 : n_own + 2*noverlap)
!
!   Index:  1          ...  noverlap | noverlap+1 ... n_own+noverlap | n_own+noverlap+1 ... n_own+2*noverlap
!           ^left overlap^           | ^--- owned interior points ---^| ^right overlap^
!
!  After the exchange:
!   T(1 .. noverlap)                  = fresh copy of left neighbour's rightmost noverlap points
!   T(noverlap+1 .. n_own+noverlap)   = this rank's own points  (just updated)
!   T(n_own+noverlap+1 .. n_own+2*noverlap) = fresh copy of right neighbour's leftmost noverlap points
!
!
!  Compile:  mpif90 -O2 -o heat1d heat1d.f90
!  Run:      mpirun -n 4 ./heat1d
!=============================================================================
program heat1d
  use mpi
  use solver_utils
  implicit none

  !--------------------------------------------------------------------------
  ! Numerical scheme parameter — change this to match a higher-order stencil
  !--------------------------------------------------------------------------
  integer,  parameter :: noverlap = 1    ! points exchanged at each boundary
                                         ! = 1 for 3-pt stencil (this program)
                                         ! = 2 for 5-pt stencil
                                         ! = 3 for 7-pt stencil

  !--------------------------------------------------------------------------
  ! Physical / grid parameters
  !--------------------------------------------------------------------------
  integer,  parameter :: N_global = 40       ! total grid points
  real(8),  parameter :: L        = 1.0d0    ! rod length (m)
  real(8),  parameter :: alpha    = 0.01d0   ! thermal diffusivity (m²/s)
  real(8),  parameter :: t_end    = 5.0d0    ! simulation end time (s)
  real(8),  parameter :: T_left   = 100.0d0  ! left boundary temperature (°C)
  real(8),  parameter :: T_right  = 0.0d0    ! right boundary temperature (°C)
  integer,  parameter :: n_print  = 5        ! print profile this many times

  !--------------------------------------------------------------------------
  ! MPI variables
  !--------------------------------------------------------------------------
  integer :: rank, nprocs, ierr
  integer :: left_rank, right_rank
  integer :: status(MPI_STATUS_SIZE)

  !--------------------------------------------------------------------------
  ! Domain decomposition
  !--------------------------------------------------------------------------
  integer :: n_own        ! number of grid points this rank OWNS (its real domain)
  integer :: n_total      ! n_own + 2*noverlap  (size of the full local array)

  ! The local temperature array includes overlap regions on both sides.
  ! Real owned points sit at indices  noverlap+1  through  noverlap+n_own.
  real(8), allocatable :: T(:)        ! temperature at current step
  real(8), allocatable :: T_new(:)    ! temperature at next step

  !--------------------------------------------------------------------------
  ! Numerics
  !--------------------------------------------------------------------------
  real(8)  :: dx, dt, r
  integer  :: i, step, n_steps
  real(8)  :: t_now
  real(8)  :: t_wall_start, t_wall_end

  !--------------------------------------------------------------------------
  ! Initialise MPI and identify neighbours
  !--------------------------------------------------------------------------
  call MPI_Init(ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, rank,   ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, nprocs, ierr)

  ! MPI_PROC_NULL = "no neighbour" — any Send/Recv to it is silently ignored,
  ! so the leftmost and rightmost ranks need no special if-statements.
  left_rank  = merge(rank - 1, MPI_PROC_NULL, rank > 0)
  right_rank = merge(rank + 1, MPI_PROC_NULL, rank < nprocs - 1)

  !--------------------------------------------------------------------------
  ! Divide the grid (requires N_global divisible by nprocs)
  !--------------------------------------------------------------------------
  if (mod(N_global, nprocs) /= 0) then
    if (rank == 0) write(*,'(A,I0,A,I0)') &
      'ERROR: N_global must be divisible by nprocs. Got ', N_global, ' / ', nprocs
    call MPI_Finalize(ierr); stop
  end if

  n_own   = N_global / nprocs           ! points this rank truly owns
  n_total = n_own + 2*noverlap          ! owned + overlap on both sides

  !--------------------------------------------------------------------------
  ! Grid spacing and time step (stability: r <= 0.5)
  !--------------------------------------------------------------------------
  dx = L / real(N_global - 1, 8)
  dt = 0.4d0 * dx**2 / alpha            ! r = 0.4 — comfortable margin
  r  = alpha * dt / dx**2
  n_steps = int(t_end / dt) + 1

  !--------------------------------------------------------------------------
  ! Allocate arrays
  !--------------------------------------------------------------------------
  allocate(T    (n_total))
  allocate(T_new(n_total))

  !--------------------------------------------------------------------------
  ! Initial condition: all points at zero
  ! Boundary ranks set their physical boundary values in the overlap slot
  ! and in their first/last owned point so the overlap exchange propagates
  ! the BC correctly from the first step.
  !--------------------------------------------------------------------------
  T(:) = 0.0d0

  if (rank == 0) then
    ! Left physical boundary — lives in overlap slot 1..noverlap
    T(1:noverlap) = T_left
    ! Also set the first owned point so the stencil is correct immediately
    T(noverlap + 1) = T_left
  end if

  if (rank == nprocs - 1) then
    ! Right physical boundary — lives in the rightmost overlap slots
    T(n_total - noverlap + 1 : n_total) = T_right
    T(noverlap + n_own) = T_right
  end if

  !--------------------------------------------------------------------------
  ! Print run information
  !--------------------------------------------------------------------------
  if (rank == 0) then
    write(*,'(A)')       repeat('=', 62)
    write(*,'(A)')       '  1D Heat Conduction — Overlapping Domain Decomposition'
    write(*,'(A)')       repeat('=', 62)
    write(*,'(A,I0)')    '  Global grid points  : ', N_global
    write(*,'(A,I0)')    '  MPI processes       : ', nprocs
    write(*,'(A,I0)')    '  Points owned/rank   : ', n_own
    write(*,'(A,I0)')    '  Overlap (noverlap)  : ', noverlap
    write(*,'(A,I0)')    '  Array size/rank     : ', n_total
    write(*,'(A,ES9.3)') '  Grid spacing dx     : ', dx
    write(*,'(A,ES9.3)') '  Time step dt        : ', dt
    write(*,'(A,F5.3)')  '  Stability param r   : ', r
    write(*,'(A,I0)')    '  Total time steps    : ', n_steps
    write(*,'(A)')       repeat('-', 62)
    write(*,'(A,I0,A)')  '  Each rank exchanges ', noverlap, &
                         ' point(s) with each neighbour per step'
    write(*,'(A)')       '  Communication: PEER-TO-PEER only (no master bottleneck)'
    write(*,'(A)')       repeat('=', 62)
    write(*,*)
  end if

  t_wall_start = MPI_Wtime()

  !============================================================
  !  MAIN TIME LOOP
  !============================================================
  do step = 1, n_steps

    t_now = real(step, 8) * dt

    !----------------------------------------------------------
    !  OVERLAP EXCHANGE
    !
    !  Each rank sends its noverlap OWNED boundary points to
    !  its neighbour and receives noverlap points into its
    !  overlap region.  The owned points start at index
    !  noverlap+1 and end at noverlap+n_own.
    !
    !  RIGHT exchange:
    !    Send: T(noverlap+n_own - noverlap+1 .. noverlap+n_own)
    !          = the noverlap rightmost OWNED points
    !    Recv: T(n_total - noverlap+1 .. n_total)
    !          = into the right overlap slots
    !
    !  LEFT exchange:
    !    Send: T(noverlap+1 .. noverlap+noverlap)
    !          = the noverlap leftmost OWNED points
    !    Recv: T(1 .. noverlap)
    !          = into the left overlap slots
    !
    !  MPI_Sendrecv sends and receives simultaneously — no
    !  deadlock possible even when all ranks call it at once.
    !  Sends to MPI_PROC_NULL are silently ignored, so rank 0
    !  and the last rank need no special cases.
    !----------------------------------------------------------

    ! --- Exchange with RIGHT neighbour ---
    call MPI_Sendrecv( &
      T(noverlap + n_own - noverlap + 1), &  ! send: rightmost noverlap owned pts
      noverlap, MPI_DOUBLE_PRECISION,      &
      right_rank, 0,                       &  ! destination
      T(n_total - noverlap + 1),           &  ! recv: into right overlap slots
      noverlap, MPI_DOUBLE_PRECISION,      &
      right_rank, 1,                       &  ! source tag
      MPI_COMM_WORLD, status, ierr)

    ! --- Exchange with LEFT neighbour ---
    call MPI_Sendrecv( &
      T(noverlap + 1),          &  ! send: leftmost noverlap owned pts
      noverlap, MPI_DOUBLE_PRECISION, &
      left_rank, 1,             &  ! destination
      T(1),                     &  ! recv: into left overlap slots
      noverlap, MPI_DOUBLE_PRECISION, &
      left_rank, 0,             &  ! source tag
      MPI_COMM_WORLD, status, ierr)

    !----------------------------------------------------------
    !  APPLY FIXED BOUNDARY CONDITIONS
    !  Physical BCs live in the overlap slots of the end ranks.
    !  Re-impose them after the exchange so the exchange cannot
    !  accidentally overwrite them.
    !----------------------------------------------------------
    if (rank == 0)         T(1:noverlap)                        = T_left
    if (rank == nprocs-1)  T(n_total-noverlap+1:n_total)        = T_right

    !----------------------------------------------------------
    !  COMPUTE — 3-point finite difference stencil
    !
    !  Update ONLY the owned points: indices noverlap+1 to
    !  noverlap+n_own.  The overlap values on both sides are
    !  now fresh from the exchange so the stencil is valid
    !  all the way to the owned boundaries.
    !
    !  T_new(i) = T(i) + r * (T(i-1) - 2*T(i) + T(i+1))
    !----------------------------------------------------------
    do i = noverlap + 1,  noverlap + n_own
      T_new(i) = T(i) + r * (T(i-1) - 2.0d0*T(i) + T(i+1))
    end do

    ! Copy updated owned points back; leave overlap slots as-is
    ! (they will be refreshed at the start of the next step)
    T(noverlap+1 : noverlap+n_own) = T_new(noverlap+1 : noverlap+n_own)

    !----------------------------------------------------------
    !  Re-enforce boundary values on owned boundary points
    !----------------------------------------------------------
    if (rank == 0)         T(noverlap + 1) = T_left
    if (rank == nprocs-1)  T(noverlap + n_own) = T_right

    !----------------------------------------------------------
    !  PERIODIC OUTPUT
    !----------------------------------------------------------
    if (mod(step, n_steps / n_print) == 0 .or. step == n_steps) then
      call print_profile(T, n_own, noverlap, rank, nprocs, t_now, N_global)
    end if

  end do  ! time loop

  t_wall_end = MPI_Wtime()

  if (rank == 0) then
    write(*,'(A)')         repeat('-', 62)
    write(*,'(A,F8.4,A)')  '  Wall time : ', t_wall_end - t_wall_start, ' s'
    write(*,'(A)')         repeat('=', 62)
  end if

  deallocate(T, T_new)
  call MPI_Finalize(ierr)

end program heat1d
