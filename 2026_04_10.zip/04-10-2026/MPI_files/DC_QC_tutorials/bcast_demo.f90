program bcast_demo
  use mpi
  implicit none
  integer :: rank, ierr
  real(8) :: temperature

  call MPI_Init(ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, rank, ierr)

  ! Only rank 0 sets the value
  if (rank == 0) then
    temperature = 273.15d0
    write(*,*) 'Rank 0: I have temperature =', temperature
  end if

  ! All processes call Bcast together.
  ! Rank 0 sends; all others receive automatically.
  call MPI_Bcast( &
    temperature,          &  ! the variable to share
    1,                    &  ! how many elements
    MPI_DOUBLE_PRECISION, &  ! data type
    0,                    &  ! rank 0 is the sender
    MPI_COMM_WORLD,       &
    ierr)

  ! Now every process has the value
  write(*,*) 'Rank', rank, ': temperature is now', temperature

  call MPI_Finalize(ierr)
end program