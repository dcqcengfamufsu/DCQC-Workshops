program send_number
  use mpi
  implicit none

  integer :: rank, nprocs, ierr
  integer :: status(MPI_STATUS_SIZE)  ! required by MPI_Recv
  real(8) :: my_number

  call MPI_Init(ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, rank,   ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, nprocs, ierr)

  if (rank == 0) then

    ! ── Rank 0 sends ─────────────────────────────────
    my_number = 3.14d0
    write(*,*) 'Rank 0: sending', my_number, 'to rank 1'

    call MPI_Send( &
      my_number,            &  ! the data to send
      1,                    &  ! number of elements (1 number)
      MPI_DOUBLE_PRECISION, &  ! data type
      1,                    &  ! destination: send TO rank 1
      0,                    &  ! tag (just use 0)
      MPI_COMM_WORLD,       &  ! communicator
      ierr)

  else if (rank == 1) then

    ! ── Rank 1 receives ──────────────────────────────
    call MPI_Recv( &
      my_number,            &  ! where to store the received data
      1,                    &  ! maximum elements to receive
      MPI_DOUBLE_PRECISION, &  ! data type (must match the Send)
      0,                    &  ! source: receive FROM rank 0
      0,                    &  ! tag (must match the Send)
      MPI_COMM_WORLD,       &  ! communicator
      status,               &  ! status info (required)
      ierr)

    write(*,*) 'Rank 1: I received', my_number
  end if

  call MPI_Finalize(ierr)
end program