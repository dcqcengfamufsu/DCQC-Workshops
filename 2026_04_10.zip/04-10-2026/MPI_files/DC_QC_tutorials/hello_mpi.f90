program hello_mpi
  use mpi            ! loads the MPI library
  implicit none

  integer :: rank    ! my unique process ID (0, 1, 2, ...)
  integer :: nprocs  ! total number of processes running
  integer :: ierr    ! error code — always needed

  ! Step 1: Start MPI — must be the very first MPI call
  call MPI_Init(ierr)

  ! Step 2: Find out who I am and how many of us there are
  call MPI_Comm_rank(MPI_COMM_WORLD, rank,   ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, nprocs, ierr)

  ! Step 3: Every process prints its greeting
  write(*,*) 'Hello from rank', rank, 'out of', nprocs, 'processes'

  ! You can give rank 0 special duties
  if (rank == 0) then
    write(*,*) '  (I am rank 0 — I often act as the coordinator)'
  end if

  ! Step 4: Shut down MPI — must be the very last MPI call
  call MPI_Finalize(ierr)
end program hello_mpi