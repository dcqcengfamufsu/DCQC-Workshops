program reduce_demo
  use mpi
  implicit none
  integer :: rank, nprocs, ierr
  real(8) :: my_value, total

  call MPI_Init(ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, rank,   ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, nprocs, ierr)

  ! Each process has its own local value
  ! rank 0 → 1.0,  rank 1 → 2.0,  rank 2 → 3.0,  etc.
  my_value = real(rank + 1, 8)
  write(*,*) 'Rank', rank, ': my value =', my_value

  ! Reduce: add all values together and put the result in
  ! variable 'total' on rank 0
  call MPI_Reduce( &
    my_value,             &  ! what each process contributes
    total,                &  ! where the result goes (rank 0 only)
    1,                    &  ! how many elements
    MPI_DOUBLE_PRECISION, &  ! data type
    MPI_SUM,              &  ! operation: add them all together
    0,                    &  ! rank 0 gets the final result
    MPI_COMM_WORLD,       &
    ierr)

  if (rank == 0) then
    write(*,*)
    write(*,*) 'Sum across all processes =', total
  end if

  call MPI_Finalize(ierr)
end program