!=============================================================================
!  mpi_concepts_demo.f90
!
!  A single program that walks through every core MPI concept one at a time,
!  each in its own subroutine.  Compile and run with any number of processes.
!
!  Compile:  mpif90 -o demo mpi_concepts_demo.f90
!  Run:      mpirun -n 4 ./demo
!=============================================================================
program mpi_concepts_demo
  use mpi
  implicit none

  integer :: rank, nprocs, ierr

  call MPI_Init(ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, rank,   ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, nprocs, ierr)

  !----------------------------------------------------------------------
  ! Print a divider only from rank 0 so the output is readable
  !----------------------------------------------------------------------
  if (rank == 0) write(*,'(A)') repeat('=', 60)
  if (rank == 0) write(*,'(A,I0,A)') '  MPI Concepts Demo   (', nprocs, ' processes)'
  if (rank == 0) write(*,'(A)') repeat('=', 60)

  !----------------------------------------------------------------------
  ! Run each concept in sequence.
  ! MPI_Barrier makes sure all processes finish one demo before the
  ! next one starts — keeps the printed output easy to follow.
  !----------------------------------------------------------------------
  call MPI_Barrier(MPI_COMM_WORLD, ierr)
  call demo_rank_and_size(rank, nprocs)

  call MPI_Barrier(MPI_COMM_WORLD, ierr)
  call demo_send_recv(rank, nprocs)

  call MPI_Barrier(MPI_COMM_WORLD, ierr)
  call demo_broadcast(rank)

  call MPI_Barrier(MPI_COMM_WORLD, ierr)
  call demo_scatter_gather(rank, nprocs)

  call MPI_Barrier(MPI_COMM_WORLD, ierr)
  call demo_reduce(rank, nprocs)

  call MPI_Barrier(MPI_COMM_WORLD, ierr)
  call demo_allreduce(rank, nprocs)

  if (rank == 0) then
    write(*,*)
    write(*,'(A)') repeat('=', 60)
    write(*,'(A)') '  All demos complete!'
    write(*,'(A)') repeat('=', 60)
  end if

  call MPI_Finalize(ierr)
end program mpi_concepts_demo


!=============================================================================
!  DEMO 1 — Rank and size
!  Every process learns its own ID and the total number of processes.
!=============================================================================
subroutine demo_rank_and_size(rank, nprocs)
  use mpi
  implicit none
  integer, intent(in) :: rank, nprocs

  if (rank == 0) then
    write(*,*)
    write(*,'(A)') '--- DEMO 1: Rank and size ---'
    write(*,'(A,I0,A)') '  Total processes running = ', nprocs
  end if

  ! Every process prints its own rank
  ! (output order is not guaranteed — that is intentional)
  call MPI_Barrier(MPI_COMM_WORLD, rank)   ! reuse rank as dummy ierr here
  write(*,'(A,I0,A,I0)') '  Hello from rank ', rank, ' of ', nprocs

end subroutine demo_rank_and_size


!=============================================================================
!  DEMO 2 — Point-to-point: MPI_Send and MPI_Recv
!  Rank 0 sends a single number to rank 1, which receives and prints it.
!=============================================================================
subroutine demo_send_recv(rank, nprocs)
  use mpi
  implicit none
  integer, intent(in) :: rank, nprocs
  integer :: ierr
  integer :: status(MPI_STATUS_SIZE)
  real(8) :: value

  if (rank == 0) then
    write(*,*)
    write(*,'(A)') '--- DEMO 2: MPI_Send / MPI_Recv ---'
  end if

  if (nprocs < 2) then
    if (rank == 0) write(*,'(A)') '  (need at least 2 processes — skipping)'
    return
  end if

  if (rank == 0) then
    value = 99.0d0
    write(*,'(A,F6.1,A)') '  Rank 0: sending value = ', value, ' to rank 1'
    call MPI_Send(value, 1, MPI_DOUBLE_PRECISION, &
                  1, 0, MPI_COMM_WORLD, ierr)

  else if (rank == 1) then
    call MPI_Recv(value, 1, MPI_DOUBLE_PRECISION, &
                  0, 0, MPI_COMM_WORLD, status, ierr)
    write(*,'(A,F6.1)') '  Rank 1: received value = ', value
  end if

end subroutine demo_send_recv


!=============================================================================
!  DEMO 3 — MPI_Bcast
!  Rank 0 sets a parameter and broadcasts it so every process has it.
!  This is how you share input settings across all workers.
!=============================================================================
subroutine demo_broadcast(rank)
  use mpi
  implicit none
  integer, intent(in) :: rank
  integer :: ierr
  real(8) :: temperature

  if (rank == 0) then
    write(*,*)
    write(*,'(A)') '--- DEMO 3: MPI_Bcast ---'
    temperature = 300.0d0                   ! only rank 0 sets this
    write(*,'(A,F8.2)') '  Rank 0 sets temperature = ', temperature
  end if

  ! All processes call Bcast — rank 0 sends, everyone else receives
  call MPI_Bcast(temperature, 1, MPI_DOUBLE_PRECISION, &
                 0, MPI_COMM_WORLD, ierr)

  write(*,'(A,I0,A,F8.2)') &
    '  Rank ', rank, ' now has temperature = ', temperature

end subroutine demo_broadcast


!=============================================================================
!  DEMO 4 — MPI_Scatter and MPI_Gather
!  Rank 0 creates an array, distributes one piece to each process,
!  each process squares its values, then rank 0 collects the results.
!=============================================================================
subroutine demo_scatter_gather(rank, nprocs)
  use mpi
  implicit none
  integer, intent(in) :: rank, nprocs
  integer :: ierr, i, chunk
  integer, parameter :: N = 8             ! total elements (must divide by nprocs)
  real(8) :: full_array(N)
  real(8), allocatable :: my_piece(:)

  if (rank == 0) then
    write(*,*)
    write(*,'(A)') '--- DEMO 4: MPI_Scatter / MPI_Gather ---'
  end if

  if (mod(N, nprocs) /= 0) then
    if (rank == 0) write(*,'(A,I0,A)') &
      '  N=', N, ' does not divide evenly — skipping'
    return
  end if

  chunk = N / nprocs
  allocate(my_piece(chunk))

  ! Rank 0 fills the array: [1, 2, 3, 4, 5, 6, 7, 8]
  if (rank == 0) then
    do i = 1, N
      full_array(i) = real(i, 8)
    end do
    write(*,'(A)',advance='no') '  Full array before scatter: '
    write(*,*) full_array
  end if

  ! Scatter: send one chunk to each process
  call MPI_Scatter(full_array, chunk, MPI_DOUBLE_PRECISION, &
                   my_piece,   chunk, MPI_DOUBLE_PRECISION, &
                   0, MPI_COMM_WORLD, ierr)

  ! Each process squares its piece
  my_piece = my_piece ** 2
  write(*,'(A,I0,A)',advance='no') '  Rank ', rank, ' squared its piece: '
  write(*,*) my_piece

  ! Gather: collect all pieces back to rank 0
  call MPI_Gather(my_piece,   chunk, MPI_DOUBLE_PRECISION, &
                  full_array, chunk, MPI_DOUBLE_PRECISION, &
                  0, MPI_COMM_WORLD, ierr)

  if (rank == 0) then
    write(*,'(A)',advance='no') '  Full array after gather:   '
    write(*,*) full_array
  end if

  deallocate(my_piece)

end subroutine demo_scatter_gather


!=============================================================================
!  DEMO 5 — MPI_Reduce
!  Each process computes a local value; rank 0 gets the global sum.
!  This is the most common pattern: everyone works, one collects.
!=============================================================================
subroutine demo_reduce(rank, nprocs)
  use mpi
  implicit none
  integer, intent(in) :: rank, nprocs
  integer :: ierr
  real(8) :: local_value, global_sum

  if (rank == 0) then
    write(*,*)
    write(*,'(A)') '--- DEMO 5: MPI_Reduce ---'
  end if

  ! Each process has a different local value
  local_value = real(rank + 1, 8)         ! rank 0 → 1.0, rank 1 → 2.0, ...
  write(*,'(A,I0,A,F6.1)') &
    '  Rank ', rank, ' contributes value = ', local_value

  ! Sum all local values; result goes to rank 0
  call MPI_Reduce(local_value, global_sum, 1, MPI_DOUBLE_PRECISION, &
                  MPI_SUM, 0, MPI_COMM_WORLD, ierr)

  if (rank == 0) then
    write(*,'(A,F8.1)') '  Global sum (rank 0 only) = ', global_sum
    write(*,'(A,F8.1)') '  Expected: sum 1..N =       ', &
                         real(nprocs*(nprocs+1), 8) / 2.0d0
  end if

end subroutine demo_reduce


!=============================================================================
!  DEMO 6 — MPI_Allreduce
!  Like Reduce, but EVERY process gets the result — no Bcast needed.
!  Use this in iterative algorithms where all ranks need the global sum
!  to decide whether to keep iterating.
!=============================================================================
subroutine demo_allreduce(rank, nprocs)
  use mpi
  implicit none
  integer, intent(in) :: rank, nprocs
  integer :: ierr
  real(8) :: my_part, global_total

  if (rank == 0) then
    write(*,*)
    write(*,'(A)') '--- DEMO 6: MPI_Allreduce ---'
    write(*,'(A)') '  (Like Reduce, but every rank gets the result)'
  end if

  my_part = real(rank + 1, 8)

  ! MPI_Allreduce: sum across all processes, result stored on EVERY rank
  call MPI_Allreduce(my_part, global_total, 1, MPI_DOUBLE_PRECISION, &
                     MPI_SUM, MPI_COMM_WORLD, ierr)

  ! All ranks can now print the result — no one needs to wait for root
  write(*,'(A,I0,A,F8.1,A,F6.1)') &
    '  Rank ', rank, ': global total = ', global_total, &
    '   (my part was ', my_part, ')'

end subroutine demo_allreduce
