%-------------------------------------------------------------------------%
%                           DC-QC Workshop
%                           Modal Analysis
%                          March 27th, 2026
%              Florida State University, Tallahassee, FL
%
%                           Rutvij Bhagwat 
%                    (Postdoctoral Scholar, FSU)
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
% 1. Readme / Usage
%    - Run POD, DMD, or SPOD using isolve ==1, 2, and 3 respectively.
%    - Set parameters for all three modes in "Parameters"
%
% 2. Data
%    Open Source Cylinder data for Re 100 taken from: 
%    https://modelflows.github.io/modelflowsapp/databases/#cylinder-2d
%
%    Corrochano, A., & Le Clainche, S. (2022). 
%    Structural sensitivity in non-linear flows using direct solutions. 
%    Computers & Mathematics with Applications, 128, 69-78. 
%    DOI: https://doi.org/10.1016/j.camwa.2022.10.006
%
% 3. SPOD library
%    For computing SPOD we make use of the publically available matlab
%    implementation by Prof. Oliver Schmidt
%    https://github.com/SpectralPOD/spod_matlab
%    Towne, A., Schmidt, O. T., Colonius, T., Spectral proper orthogonal decomposition 
%    and its relationship to dynamic mode decomposition and resolvent analysis,
%    J. of Fluid Mech. 847, 821–867, 2018
%   
%
% 4. References:
%    These are some good references: 
%    (i)   Tu et al. (2014) On dynamic mode decomposition:  Theory and applications. - DMD
%    (ii)  Colonius & Towne (2025) - Chapter 2 - Modal decomposition, In Computation and Analysis of Turbulent Flows
%          Data Driven Analysis and Modeling of Turbulent Flows - POD, DMD, and SPOD
%    (iii) Towne et al (2018) Spectral proper orthogonal decomposition and its relationship to dynamic mode decomposition and resolvent analysis. 
%          Journal of Fluid Mechanics. - SPOD
%    (iv)  Taira et al. (2017) Modal Analysis of Fluid Flows: An Overview. AIAA Journal. - POD, DMD, and SPOD
%-------------------------------------------------------------------------%

clear
close all;

isolve = 3; %1: pod, 2: dmd, 3: spod
dt     = 1.0;
%-------------------------------------------------------------------------%
%     Parameters
%-------------------------------------------------------------------------%

switch isolve
   case 1 %POD
      nplot         = 10; % # of modes to be printed
      nrecon        =  0; % # of modes used for reconstruction
      doreconstruct =  0; % Perform reconstruction, if == 1
   case 2 %DMD
      itruncate    =  1; % Truncate for some r < m - 1
      rtrunc       = 10; % Usually, r << m
      doplot       =  1; % Only plot modes if doplot==1
   case 3 %SPOD
      nwidth       = 100; % Width 
      noverlap     = 50;
      doplot       = 1; % plot SPOD modes
      flist        = [16 17 18 33 34 35 48 49]; %list of freq. #s to plot modes
   otherwise
   error('Invalid Choice of isolve');
end


%-------------------------------------------------------------------------%
%     Preliminaries
%-------------------------------------------------------------------------%

load('TensorRe100.mat');
load('X.mat');
load('Y.mat');

nx = 500;
ny = 500;
nt = 500;

U = squeeze(Tensor(1,:,:,:));
V = squeeze(Tensor(2,:,:,:));
umean = zeros(nx,ny);
vmean = zeros(nx,ny);

size(Tensor);
clear Tensor;

%-------------------------------------------------------------------------%
%     Time-series 
%-------------------------------------------------------------------------%

for i=1:nt

ui = squeeze(U(:,:,i));
vi = squeeze(V(:,:,i));
umean = umean + ui*dt;
vmean = vmean + vi*dt;

%uncomment if you want timeseries snapshots
% f = figure;
% pcolor(X,Y,ui);
% axis equal tight, shading interp, caxis([-0.2 1.2]);
% ylabel('$y/D$','fontsize',18,'interpreter','latex')
% xlabel('$x/D$','fontsize',18,'interpreter','latex')
% ax = gca;   % Get the current axes handle
% ax.FontSize = 20; % Increase font size to 16
% colorbar;
% center = [0 0];
% radius = 0.5;
% pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
% rectangle('Position', pos, 'Curvature', [1 1], ...
%           'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
% saveas(gcf,['./figures/U.' num2str(i,'%03.f') '.png'])
% close(f)
% 
% f = figure;
% pcolor(X,Y,vi);
% axis equal tight, shading interp, caxis([-0.6 0.6]);
% ylabel('$y/D$','fontsize',18,'interpreter','latex')
% xlabel('$x/D$','fontsize',18,'interpreter','latex')
% ax = gca;   % Get the current axes handle
% ax.FontSize = 20; % Increase font size to 16
% colorbar;
% center = [0 0];
% radius = 0.5;
% pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
% rectangle('Position', pos, 'Curvature', [1 1], ...
%           'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
% saveas(gcf,['./figures/V.' num2str(i,'%03.f') '.png'])
% close(f)
% uncomment if you want timeseries snapshots

end
umean = umean / (nt*dt);
vmean = vmean / (nt*dt);

% uncomment if you want mean snapshots
% f = figure;
% pcolor(X,Y,umean);
% axis equal tight, shading interp, caxis([-0.2 1.2]);
% ylabel('$y/D$','fontsize',18,'interpreter','latex')
% xlabel('$x/D$','fontsize',18,'interpreter','latex')
% ax = gca;   % Get the current axes handle
% ax.FontSize = 20; % Increase font size to 16
% colorbar;
% center = [0 0];
% radius = 0.5;
% pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
% rectangle('Position', pos, 'Curvature', [1 1], ...
%           'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
% saveas(gcf,'./figures/Umean.png')
% close(f)
% 
% f = figure;
% pcolor(X,Y,vmean);
% axis equal tight, shading interp, caxis([-0.6 0.6]);
% ylabel('$y/D$','fontsize',18,'interpreter','latex')
% xlabel('$x/D$','fontsize',18,'interpreter','latex')
% ax = gca;   % Get the current axes handle
% ax.FontSize = 20; % Increase font size to 16
% colorbar;
% center = [0 0];
% radius = 0.5;
% pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
% rectangle('Position', pos, 'Curvature', [1 1], ...
%           'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
% saveas(gcf,'./figures/Vmean.png')
% close(f)
% uncomment if you want mean snapshots


switch isolve
%-------------------------------------------------------------------------%
%     POD                                                                 %
%-------------------------------------------------------------------------%
case 1
% Reference: Modal Analysis of Fluid Flows: An Overview
% Kunihiko Taira, Steven L. Brunton, Scott T. M. Dawson, Clarence W. Rowley, 
% Tim Colonius, Beverley J. McKeon, Oliver T. Schmidt, Stanislav Gordeyev, 
% Vassilios Theofilis, and Lawrence S. Ukeiley
% AIAA Journal 2017 55:12, 4013-4041


% Prepare Data    
Qu = zeros(nx*ny,nt);
Qv = zeros(nx*ny,nt);
Qrecon = zeros(2*nx*ny,nt);

acoeff = zeros(nrecon,nt);


for i = 1:nt    
   ui = squeeze(U(:,:,i));
   vi = squeeze(V(:,:,i));
   Qui = reshape(ui,[nx*ny,1]);
   Qvi = reshape(vi,[nx*ny,1]);
   Qum = reshape(umean,[nx*ny,1]);
   Qvm = reshape(vmean,[nx*ny,1]);
   Qu(:,i) = Qui - Qum; 
   Qv(:,i) = Qvi - Qvm; 
end

Q  = [Qu;Qv];
Qm = [Qum;Qvm];

% Compute POD modes    

Rprime = Q'* Q; %Snapshot method, Rprime \in (m x m)
[Psi_tmp,Lambda_tmp] = eig(Rprime); % Eq. (30) of Taira et al. (2017) AIAA 

% Sort (eig not sorted, unlike svd)
[~, ind] = sort(diag(Lambda_tmp),'descend'); 
Lambda   = Lambda_tmp(ind, ind);
Psi      = Psi_tmp(:, ind);

Lambda_inv_sqrt = diag((diag(Lambda)).^(-0.5));

Phi = Q * Psi * (Lambda_inv_sqrt); % Eq. (32) of Taira et al. (2017) AIAA

lambda_vec = diag(Lambda) / sum(diag(Lambda));
f = figure; 
axis equal tight;
loglog(lambda_vec,'b.',MarkerSize=20)
ylabel('$\lambda_j / \sum^m_{j=1} \lambda_j$','fontsize',18,'interpreter','latex')
xlabel('Mode \#, $j$','fontsize',18,'interpreter','latex')
ax = gca;   % Get the current axes handle
ax.FontSize = 20; % Increase font size to 16
saveas(gcf,'./figures/POD_eigenvalues.png')
close(f)


% Plot POD modes
for iplot = 1:nplot
    f = figure;
    u1d = Phi(1:nx*ny,iplot);
    ui = reshape(u1d,[nx,ny]);
    pcolor(X,Y,ui);
    axis equal tight, shading interp, caxis([min(min(ui)) max(max(ui))]);
    ylabel('$y/D$','fontsize',18,'interpreter','latex')
    xlabel('$x/D$','fontsize',18,'interpreter','latex')
    ax = gca;   % Get the current axes handle
    ax.FontSize = 20; % Increase font size to 16
    colorbar;
    center = [0 0];
    radius = 0.5;
    pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
    rectangle('Position', pos, 'Curvature', [1 1], ...
              'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
    saveas(gcf,['./figures/POD-mode-U.' num2str(iplot,'%03.f') '.png'])
    close(f)    

    f = figure;
    v1d = Phi(nx*ny+1:2*nx*ny,iplot);
    vi = reshape(v1d,[nx,ny]);
    pcolor(X,Y,vi);

    axis equal tight, shading interp, caxis([min(min(vi)) max(max(vi))]);
    ylabel('$y/D$','fontsize',18,'interpreter','latex')
    xlabel('$x/D$','fontsize',18,'interpreter','latex')
    ax = gca;   % Get the current axes handle
    ax.FontSize = 20; % Increase font size to 16
    colorbar;
    center = [0 0];
    radius = 0.5;
    pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
    rectangle('Position', pos, 'Curvature', [1 1], ...
              'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
    saveas(gcf,['./figures/POD-mode-V.' num2str(iplot,'%03.f') '.png'])
    close(f)    

end

% Compute temporal coefficients
for irecon = 1:nrecon
   for i = 1:nt
      acoeff(irecon,i) = Phi(:,irecon)' * Q(:,i);
   end
end

if (doreconstruct == 1)
for i = 1:nt
   Qrecon(:,i) = Qm;
   for irecon = 1:nrecon
      Qrecon(:,i) = Qrecon(:,i) + acoeff(irecon,i) * Phi(:,irecon);  
   end
end

% Plot Reconstructed Field
for i=1:nt

%uncomment if you want reconstructed snapshots
f = figure;
u1d = Qrecon(1:nx*ny,i);
ui = reshape(u1d,[nx,ny]);
pcolor(X,Y,ui);
axis equal tight, shading interp, caxis([-0.2 1.2]);
ylabel('$y/D$','fontsize',18,'interpreter','latex')
xlabel('$x/D$','fontsize',18,'interpreter','latex')
ax = gca;   % Get the current axes handle
ax.FontSize = 20; % Increase font size to 16
colorbar;
center = [0 0];
radius = 0.5;
pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
rectangle('Position', pos, 'Curvature', [1 1], ...
          'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
saveas(gcf,['./figures/Urecon.' num2str(nrecon,'%03.f') '.' num2str(i,'%03.f')  '.png'])
close(f)

f = figure;
v1d = Qrecon(nx*ny+1:2*nx*ny,i);
vi = reshape(v1d,[nx,ny]);
pcolor(X,Y,vi);
axis equal tight, shading interp, caxis([-0.6 0.6]);
ylabel('$y/D$','fontsize',18,'interpreter','latex')
xlabel('$x/D$','fontsize',18,'interpreter','latex')
ax = gca;   % Get the current axes handle
ax.FontSize = 20; % Increase font size to 16
colorbar;
center = [0 0];
radius = 0.5;
pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
rectangle('Position', pos, 'Curvature', [1 1], ...
          'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
saveas(gcf,['./figures/Vrecon.' num2str(nrecon,'%03.f') '.' num2str(i,'%03.f')  '.png'])
close(f)
% uncomment if you want reconstructed snapshots

end
end 

%-------------------------------------------------------------------------%
%     DMD                                                                 %
%-------------------------------------------------------------------------%% 
% Reference: Modal Analysis of Fluid Flows: An Overview
% Kunihiko Taira, Steven L. Brunton, Scott T. M. Dawson, Clarence W. Rowley, 
% Tim Colonius, Beverley J. McKeon, Oliver T. Schmidt, Stanislav Gordeyev, 
% Vassilios Theofilis, and Lawrence S. Ukeiley
% AIAA Journal 2017 55:12, 4013-4041
%
% Reference: Jonathan H. Tu, Clarence W. Rowley, Dirk M. Luchtenburg, Steven L. Brunton, 
% J. Nathan Kutz. On dynamic mode decomposition:  Theory and applications.
% Arxiv: https://arxiv.org/abs/1312.0041% 


case 2
% Prepare Data    
Qu = zeros(nx*ny,nt);
Qv = zeros(nx*ny,nt);

for i = 1:nt    
   ui = squeeze(U(:,:,i));
   vi = squeeze(V(:,:,i));
   Qui = reshape(ui,[nx*ny,1]);
   Qvi = reshape(vi,[nx*ny,1]);
   Qum = reshape(umean,[nx*ny,1]);
   Qvm = reshape(vmean,[nx*ny,1]);
   Qu(:,i) = Qui; 
   Qv(:,i) = Qvi; 
end

Q  = [Qu;Qv];
QX = Q(:,1:nt-1);
QY = Q(:,2:nt);

Qm = [Qum;Qvm];

[Us,Ss,Vs] = svd(QX,'econ'); % m << n

if (itruncate == 1) % r << m
    Us = Us(:,1:rtrunc);
    Ss = Ss(1:rtrunc,1:rtrunc);
    Vs = Vs(:,1:rtrunc);
end    

Atilde = Us' * QY * Vs * diag(1./diag(Ss)); % Eq. (47) of Taira et al. (2017) AIAA [CORRECTED VERSION!] 
Sigma_inv = diag(1./diag(Ss));

[Ve,De] = eig(Atilde);
Phi = QY * Vs * diag(1./diag(Ss)) * Ve; % Eq. (48) of Taira et al. (2017) AIAA [CORRECTED VERSION!]

for i = 1:size(Phi,2)
    Phi2 = Phi * (1./De(i,i));
end

% Plot DMD modes
if (doplot==1)
    for iplot = 1:size(Phi,2)
        f = figure;
        u1d = real(Phi(1:nx*ny,iplot));
        ui = reshape(u1d,[nx,ny]);
        pcolor(X,Y,ui);
        axis equal tight, shading interp;
        if (min(min(ui)) ~= max(max(ui))) 
           clim([min(min(ui)) max(max(ui))])
        end
        ylabel('$y/D$','fontsize',18,'interpreter','latex')
        xlabel('$x/D$','fontsize',18,'interpreter','latex')
        ax = gca;   % Get the current axes handle
        ax.FontSize = 20; % Increase font size to 16
        colorbar;
        center = [0 0];
        radius = 0.5;
        pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
        rectangle('Position', pos, 'Curvature', [1 1], ...
            'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
        %saveas(gcf,['./figures/DMD-mode-Ureal.' num2str(iplot,'%03.f') '.png'])
        close(f)


        f = figure;
        u1d = imag(Phi(1:nx*ny,iplot));
        ui = reshape(u1d,[nx,ny]);
        pcolor(X,Y,ui);
        axis equal tight, shading interp;
        if (min(min(ui)) ~= max(max(ui))) 
           clim([min(min(ui)) max(max(ui))])
        end
        ylabel('$y/D$','fontsize',18,'interpreter','latex')
        xlabel('$x/D$','fontsize',18,'interpreter','latex')
        ax = gca;   % Get the current axes handle
        ax.FontSize = 20; % Increase font size to 16
        colorbar;
        center = [0 0];
        radius = 0.5;
        pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
        rectangle('Position', pos, 'Curvature', [1 1], ...
            'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
        %saveas(gcf,['./figures/DMD-mode-Uimag.' num2str(iplot,'%03.f') '.png'])
        close(f)

        f = figure;
        v1d = real(Phi(nx*ny+1:2*nx*ny,iplot));
        vi = reshape(v1d,[nx,ny]);
        pcolor(X,Y,vi);
        axis equal tight, shading interp;
        if (min(min(vi)) ~= max(max(vi))) 
           clim([min(min(vi)) max(max(vi))])
        end
        ylabel('$y/D$','fontsize',18,'interpreter','latex')
        xlabel('$x/D$','fontsize',18,'interpreter','latex')
        ax = gca;   % Get the current axes handle
        ax.FontSize = 20; % Increase font size to 16
        colorbar;
        center = [0 0];
        radius = 0.5;
        pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
        rectangle('Position', pos, 'Curvature', [1 1], ...
            'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
        %saveas(gcf,['./figures/DMD-mode-Vreal.' num2str(iplot,'%03.f') '.png'])
        close(f)

        f = figure;
        v1d = imag(Phi(nx*ny+1:2*nx*ny,iplot));
        vi = reshape(v1d,[nx,ny]);
        pcolor(X,Y,vi);
        axis equal tight, shading interp;
        if (min(min(vi)) ~= max(max(vi))) 
           clim([min(min(vi)) max(max(vi))])
        end
        ylabel('$y/D$','fontsize',18,'interpreter','latex')
        xlabel('$x/D$','fontsize',18,'interpreter','latex')
        ax = gca;   % Get the current axes handle
        ax.FontSize = 20; % Increase font size to 16
        colorbar;
        center = [0 0];
        radius = 0.5;
        pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
        rectangle('Position', pos, 'Curvature', [1 1], ...
            'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
        %saveas(gcf,['./figures/DMD-mode-Vimag.' num2str(iplot,'%03.f') '.png'])
        close(f)

    end
end

f = figure; 
plot(real(diag(De)),imag(diag(De)),'r.',MarkerSize=20)
xlabel('$\lambda_r$','fontsize',18,'interpreter','latex')
ylabel('$\lambda_i$','fontsize',18,'interpreter','latex')
axis equal;
ax = gca;   % Get the current axes handle
ax.FontSize = 20; % Increase font size to 16
center = [0 0];
radius = 1.0;
pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
rectangle('Position', pos, 'Curvature', [1 1], ...
           'EdgeColor', [0.01 0.01 0.01], 'LineWidth', 3,'LineStyle', '--');
%saveas(gcf,'./figures/DMD_eigenvalues.png')
close(f)

%-------------------------------------------------------------------------%
%     SPOD                                                                %
%-------------------------------------------------------------------------%
case 3
% SPOD Library: https://github.com/SpectralPOD/spod_matlab
% 
% For computing SPOD we make use of the publically available matlab
% implementation by Prof. Oliver Schmidt
% https://github.com/SpectralPOD/spod_matlab
% 
% Reference Towne, A., Schmidt, O. T., Colonius, T., Spectral proper orthogonal decomposition 
% and its relationship to dynamic mode decomposition and resolvent analysis,
% J. of Fluid Mech. 847, 821–867, 2018
% 

addpath('./spod_library/')  

% Prepare Data    
Qu = zeros(nx*ny,nt);
Qv = zeros(nx*ny,nt);

for i = 1:nt    
   ui = squeeze(U(:,:,i));
   vi = squeeze(V(:,:,i));
   Qui = reshape(ui,[nx*ny,1]);
   Qvi = reshape(vi,[nx*ny,1]);
   Qum = reshape(umean,[nx*ny,1]);
   Qvm = reshape(vmean,[nx*ny,1]);
   Qu(:,i) = Qui; 
   Qv(:,i) = Qvi; 
end
Q  = [Qu;Qv];
Q21 = permute(Q,[2 1]);

[L,P,f] = spod(Q21,ones(1,nwidth),[],noverlap,dt);

f1=figure;
semilogy(L,LineWidth=2.5)
xlabel('$f$','fontsize',18,'interpreter','latex')
ylabel('$\Lambda$','fontsize',18,'interpreter','latex')
ax = gca;   % Get the current axes handle
ax.FontSize = 20; % Increase font size to 16
%saveas(gcf,'./figures/SPOD_eigenvalues.png')
close(f1)

% Plot SPOD modes
if (doplot == 1)
for iplot = 1: length(flist)
   for im = 1:2
   f1 = figure;
   u1d = real(P(flist(iplot),1:nx*ny,im));
   ui = reshape(u1d,[nx,ny]);
   pcolor(X,Y,ui);
   axis equal tight, shading interp;
   if (min(min(ui)) ~= max(max(ui))) 
      clim([min(min(ui)) max(max(ui))])
   end
   ylabel('$y/D$','fontsize',18,'interpreter','latex')
   xlabel('$x/D$','fontsize',18,'interpreter','latex')
   ax = gca;   % Get the current axes handle
   ax.FontSize = 20; % Increase font size to 16
   colorbar;
   center = [0 0];
   radius = 0.5;
   pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
   rectangle('Position', pos, 'Curvature', [1 1], ...
        'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
   %saveas(gcf,['./figures/SPOD-mode-Ureal.' num2str(iplot,'%03.f')  '.' num2str(im,'%03.f')  '.png'])
   close(f1)

   f1 = figure;
   v1d = real(P(flist(iplot),nx*ny+1:2*nx*ny,im));
   vi = reshape(v1d,[nx,ny]);
   pcolor(X,Y,vi);
   axis equal tight, shading interp;
   if (min(min(vi)) ~= max(max(vi))) 
      clim([min(min(vi)) max(max(vi))])
   end
   ylabel('$y/D$','fontsize',18,'interpreter','latex')
   xlabel('$x/D$','fontsize',18,'interpreter','latex')
   ax = gca;   % Get the current axes handle
   ax.FontSize = 20; % Increase font size to 16
   colorbar;
   center = [0 0];
   radius = 0.5;
   pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
   rectangle('Position', pos, 'Curvature', [1 1], ...
        'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
   %saveas(gcf,['./figures/SPOD-mode-Vreal.' num2str(iplot,'%03.f')  '.' num2str(im,'%03.f')  '.png'])
   close(f1)

   f1 = figure;
   u1d = imag(P(flist(iplot),1:nx*ny,im));
   ui = reshape(u1d,[nx,ny]);
   pcolor(X,Y,ui);
   axis equal tight, shading interp;
   if (min(min(ui)) ~= max(max(ui))) 
      clim([min(min(ui)) max(max(ui))])
   end
   ylabel('$y/D$','fontsize',18,'interpreter','latex')
   xlabel('$x/D$','fontsize',18,'interpreter','latex')
   ax = gca;   % Get the current axes handle
   ax.FontSize = 20; % Increase font size to 16
   colorbar;
   center = [0 0];
   radius = 0.5;
   pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
   rectangle('Position', pos, 'Curvature', [1 1], ...
        'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
   %saveas(gcf,['./figures/SPOD-mode-Uimag.' num2str(iplot,'%03.f')  '.' num2str(im,'%03.f')  '.png'])
   close(f1)

   f1 = figure;
   v1d = imag(P(flist(iplot),nx*ny+1:2*nx*ny,im));
   vi = reshape(v1d,[nx,ny]);
   pcolor(X,Y,vi);
   axis equal tight, shading interp;
   if (min(min(vi)) ~= max(max(vi))) 
      clim([min(min(vi)) max(max(vi))])
   end
   ylabel('$y/D$','fontsize',18,'interpreter','latex')
   xlabel('$x/D$','fontsize',18,'interpreter','latex')
   ax = gca;   % Get the current axes handle
   ax.FontSize = 20; % Increase font size to 16
   colorbar;
   center = [0 0];
   radius = 0.5;
   pos = [center(1)-radius, center(2)-radius, 2*radius, 2*radius];
   rectangle('Position', pos, 'Curvature', [1 1], ...
        'FaceColor', [0.99 0.99 0.99], 'EdgeColor', [0.99 0.99 0.99], 'LineWidth', 1);
   %saveas(gcf,['./figures/SPOD-mode-Vimag.' num2str(iplot,'%03.f') '.' num2str(im,'%03.f') '.png'])
   close(f1)
   end

   end
end


%-------------------------------------------------------------------------%
%    End                                                                  %
%-------------------------------------------------------------------------%
otherwise
error('Invalid Choice of isolve');
end
