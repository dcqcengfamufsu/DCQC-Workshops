%-------------------------------------------------------------------------%
%                           DC-QC Workshop
%                           Modal Analysis
%                          March 27th, 2026
%              Florida State University, Tallahassee, FL
%
%                           Rutvij Bhagwat 
%                    (Postdoctoral Scholar, FSU)                          
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
% Code for Resolvent Analysis (rigid wall, laminar flow)
% - builds a linear operator for a laminar channel flow for U = 1-y.^2;
% y \in [-1,1]. Computes Resolvent gain over a range of frequencies
% & compares with the results obtained using the code of Schmid & Brandt (2014)
%-------------------------------------------------------------------------%
clear;
close all;

%-------------------------------------------------------------------------%
%     Parameters
%-------------------------------------------------------------------------%
Re = 2000;
kx = 1;
kz = 0.1;
ny = 128;
omg = linspace(-0.5,1.5,201);
ne = 4;

%-------------------------------------------------------------------------%
%     Preparation
%-------------------------------------------------------------------------%
D = -gallery('chebspec',ny,0);  %chebishev polynomial
D2=D*D;
Teta=[0:ny-1]./(ny-1).*pi;
x=-cos(Teta);x=x';

y = x;
U = 1.0 - y.^2; 

datafinal = zeros(length(omg),2);

%-------------------------------------------------------------------------%
% 
% LOOP OVER OMEGA 
%
%-------------------------------------------------------------------------%

for iloop = 1:length(omg)
%-------------------------------------------------------------------------%
%     Build Linear Operator
%-------------------------------------------------------------------------%

N = ne*ny;
Amat = zeros(N,N);
dU = D * U;
for i = 1:ny
   ib = (i-1)*ne;

   Amat(ib+1,ib+1) = (1/Re)*(-kx^2 - kz^2) -1i*kx*U(i);
   Amat(ib+1,ib+2) = -dU(i);
   Amat(ib+1,ib+4) = -1i*kx;

   Amat(ib+2,ib+2) = (1/Re)*(-kx^2 - kz^2) -1i*kx*U(i);

   Amat(ib+3,ib+3) = (1/Re)*(-kx^2 - kz^2) -1i*kx*U(i);
   Amat(ib+3,ib+4) = -1i*kz;

   Amat(ib+4,ib+1) = -1i*kx;
   Amat(ib+4,ib+3) = -1i*kz;

   %For terms involving derivative 
   for j = 1:ny
       jb = (j-1)*ne;
       Amat(ib+1,jb+1) = Amat(ib+1,jb+1) + (1/Re)*(D2(i,j)) ;

       Amat(ib+2,jb+2) = Amat(ib+2,jb+2) + (1/Re)*(D2(i,j)) ;
       Amat(ib+2,jb+4) = Amat(ib+2,jb+4) - (D(i,j)) ;

       Amat(ib+3,jb+3) = Amat(ib+3,jb+3) + (1/Re)*(D2(i,j)) ;

       Amat(ib+4,jb+2) = Amat(ib+4,jb+2) - (D(i,j)) ;
   end
end

Bmat = zeros(N,N);
for i = 1:ny
   ib = (i-1)*ne;
   Bmat(ib+1,ib+1) = 1.0;
   Bmat(ib+2,ib+2) = 1.0;
   Bmat(ib+3,ib+3) = 1.0;
end

Lmat = -1i * omg(iloop) * Bmat - Amat; %LHS
RHS  = Bmat;

%-------------------------------------------------------------------------%
%     Boundary Conditions
%-------------------------------------------------------------------------%

% BC treatment similar to Luhar github implementation:
% https://github.com/mluhar/resolvent/blob/modular/pipeBC.m

%Implement BCs 

%bottom (u,v,w = 0 for x,y,z mom. eq. & dv/dy = 0 for continuity)
RHS(1,:) = 0.0; 
RHS(2,:) = 0.0; 
RHS(3,:) = 0.0; 
RHS(4,:) = 0.0; 

Lmat(1,:) = 0.0; 
Lmat(2,:) = 0.0; 
Lmat(3,:) = 0.0; 
Lmat(4,:) = 0.0; 

Lmat(1,1) = 1.0; 
Lmat(2,2) = 1.0; 
Lmat(3,3) = 1.0;
for j = 1:ny
   jb = (j-1)*ne;
   Lmat(4,jb+2) = D(1,j);
end

%top (u,v,w = 0 for x,y,z mom. eq. & dv/dy = 0 for continuity)
RHS(N-ne + 1,:) = 0.0; 
RHS(N-ne + 2,:) = 0.0; 
RHS(N-ne + 3,:) = 0.0; 
RHS(N-ne + 4,:) = 0.0; 

Lmat(N-ne + 1,:) = 0.0; 
Lmat(N-ne + 2,:) = 0.0; 
Lmat(N-ne + 3,:) = 0.0; 
Lmat(N-ne + 4,:) = 0.0; 

Lmat(N-ne + 1,N-ne + 1) = 1.0; 
Lmat(N-ne + 2,N-ne + 2) = 1.0; 
Lmat(N-ne + 3,N-ne + 3) = 1.0;
for j = 1:ny
   jb = (j-1)*ne;
   Lmat(N-ne + 4,jb+2) = D(ny,j);
end

%-------------------------------------------------------------------------%
%     Build Resolvent Operator
%-------------------------------------------------------------------------%
% H = LHS^-1 (RHS) ; 
Rmat = Lmat \ RHS; 

%-------------------------------------------------------------------------%
%     Build Weights
%  clencurt.m to build Chebyshev Int. Weights:
%  https://github.com/mluhar/resolvent/blob/modular/clencurt.m
%  http://people.maths.ox.ac.uk/trefethen/clencurt.m
%-------------------------------------------------------------------------%
wvec=zeros(N,1);
[ytmp, wline] = clencurt(ny-1) ;

for j=1:ny
   jb = (j-1)*ne;
   wvec(jb+1) = wline(j);
   wvec(jb+2) = wline(j);
   wvec(jb+3) = wline(j);
   wvec(jb+4) = 0.0;     %pressure not included in the KE norm. 
end

Wp=diag(sqrt(wvec));
Wn=diag(1./sqrt(wvec + 1.0e-14));

Hmat = Wp*Rmat*Wn; %weighted transfer function
[Um,Sm,Vm] = svd(Hmat);

datafinal(iloop,1) = omg(iloop);
datafinal(iloop,2) = Sm(1,1);

end % ILOOP

%-------------------------------------------------------------------------%
%     Test
%-------------------------------------------------------------------------%
f1 = figure; 
semilogy(datafinal(:,1),datafinal(:,2),'b-',LineWidth=2.5); hold on;
% For comparison, data generated using the code given in Supplemental Materials of:
% https://asmedigitalcollection.asme.org/appliedmechanicsreviews/article-abstract/66/2/024803/395151/Analysis-of-Fluid-Systems-Stability-Receptivity?redirectedFrom=fulltext
exact = dlmread('exact_schmid.dat');
semilogy(exact(:,1),exact(:,2),'r--',LineWidth=2.5); hold on;
xlabel('$\omega$','fontsize',18,'interpreter','latex')
ylabel('$\sigma_1$','fontsize',18,'interpreter','latex')
ax = gca;   % Get the current axes handle
ax.FontSize = 20; % Increase font size to 16
legend('Present','Schmid \& Brandt (2014)','fontsize',16,'interpreter','latex','location','best')
%saveas(gcf,'Resolvent_channel.png')
%close(f1)
